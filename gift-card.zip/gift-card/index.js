const express = require("express");
const path = require("path");
const { check, validationResult } = require("express-validator");
const mongoose = require("mongoose");
const session = require("express-session");
const nodemailer = require("nodemailer");
var MongoClient = require("mongodb").MongoClient;
// this url is used in search text functionality
var url = "mongodb://localhost:27017/";

var myApp = express();
mongoose.connect("mongodb://localhost:27017/giftcards", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const CustomerInfo = mongoose.model("CustomerInfo", {
  customer: String,
  forCustomer: String,
  forCustomerEmail: String,
  buyCustomer: String,
  buyCustomerEmail: String,
  barcodeNumber: String,
});

const EmpCard = mongoose.model("EmpCard", {
  empNameLogin: String,
  barcodeNumber: String,
  today: String,
});

const CardInfo = mongoose.model("CardInfo", {
  barcodeNumber: String,
  totalPeople: String,
  mealoption1: String,
  mealoption2: String,
  today: String,
});

// define the model
const Cards = mongoose.model("Cards", {
  status: String,
  customer: String,
  forCustomer: String,
  forCustomerEmail: String,
  buyCustomer: String,
  buyCustomerEmail: String,
  department: String,
  totalPeople: String,
  mealoption1: String,
  mealoption2: String,
  barcodeNumber: String,
  today: String,
});

const Admin = mongoose.model("Admin", {
  adminName: String,
  adminPass: String,
});

const Employee = mongoose.model("Employee", {
  empName: String,
  empPass: String,
});

myApp.use(
  session({
    secret: "bloomgiftcardsgenerator",
    resave: false,
    saveUninitialized: true,
  })
);

myApp.use(express.urlencoded({ extended: false }));

// set paths to public and view folder
myApp.set("view engine", "ejs");
myApp.set("views", path.join(__dirname, "views"));
myApp.use(express.static(__dirname + "/public"));

// Login page
myApp.get("/login", function (req, res) {
  res.render("login");
});

// Authenticating login credentials
myApp.post(
  "/loginUser",
  [
    check("username", "Username is mandatory").trim().notEmpty(),
    check("userpassword", "Password is mandatory").trim().notEmpty(),
  ],
  function (req, res) {
    let userNames = req.body.username;
    let userPassword = req.body.userpassword;
    const errors = validationResult(req);
    if (errors.isEmpty()) {
      Admin.findOne({ adminName: userNames, adminPass: userPassword }).exec(
        function (err, admin) {
          if (admin) {
            req.session.adminName = admin.adminName;
            req.session.loggedIn = true;
            res.redirect("/allCards");
          } else {
            Employee.findOne({
              empName: userNames,
              empPass: userPassword,
            }).exec(function (err, emp) {
              if (emp) {
                req.session.empName = emp.empName;
                req.session.loggedIn = true;
                res.redirect("/allCardsEmp");
              } else {
                // return res.status(404).json({ error: "No Profile Found" });
                // let outMessage = "Username not found, Please try again."
                res.redirect("/login");
              }
            });
          }
        }
      );
    } else {
      // console.log(errors);
      res.render("login", {
        errors: errors.array(),
        userData: req.body,
      });
    }
  }
);

// logout page
myApp.get("/logout", function (req, res) {
  req.session.adminName = "";
  req.session.loggedIn = false;
  res.render("logout");
});

// Login page
myApp.get("/", function (req, res) {
  res.render("login");
});

myApp.get("/navigate",function(req,res){
  res.render("navigateAdmin");
});

myApp.get("/navigateEmp",function(req,res){
  res.render("navigateEmp");
});

myApp.get("/generate",function(req,res){
  res.render("navigationInfo");
});
myApp.get("/redeem",function(req,res){
  res.render("redeemCard");
});
myApp.get("/update",function(req,res){
  res.render("updateCard");
});
// Login page
myApp.get("/redeemSuccessEmp", function (req, res) {
  res.render("redeemSuccessEmp");
});

myApp.post("/active", function(req,res){
  if (req.session.loggedIn){
    MongoClient.connect(url, function (err, db){
      if (err) throw err;
      var dbo = db.db("giftcards");
      var query = {status:"Active"};
      dbo.collection("cards").find({"status":"Active"}).count().then(function(resultActive){
        var active = "";
        active += resultActive;
        res.render("activeCards",{active});
      });
    });
  }
});

myApp.post("/rdeem", function(req,res){
  if (req.session.loggedIn){
    MongoClient.connect(url, function (err, db){
      if (err) throw err;
      var dbo = db.db("giftcards");
      var query = {status:"Active"};
      dbo.collection("cards").find({"status":"Redeemed"}).count().then(function(resultRedeem){
        var redeemed = "";
        redeemed += resultRedeem;
        res.render("redeemedCards",{redeemed});
      });
    });
  }
});

// Home page
myApp.get("/home", function (req, res) {
  res.render("home");
});

// Checking if total people equals meal option1 + meal option2
function mealCheck(value, { req }) {
  if (
    parseInt(req.body.mealoption1) + parseInt(req.body.mealoption2) ==
    parseInt(req.body.peoplecount)
  ) {
    return true;
  } else {
    throw new Error(
      "Adding both meal options should equal total people dining"
    );
  }
}

// to display all gift cards for admin
myApp.get("/allCards", function (req, res) {
  if (req.session.loggedIn) {
    Cards.find({}).exec(function (err, cards) {
      res.render("allCards", { cards: cards });
    });
  } else {
    res.redirect("/login");
  }
});

// to display all customers info for admin
myApp.get("/customers", function (req, res) {
  if (req.session.loggedIn) {
    CustomerInfo.find({}).exec(function (err, custCards) {
      res.render("customers", { cards: custCards });
    });
  } else {
    res.redirect("/login");
  }
});

// to display all cards info for admin
myApp.get("/cardInfo", function (req, res) {
  if (req.session.loggedIn) {
    CardInfo.find({}).exec(function (err, cardsInfo) {
      res.render("cardsInfo", { cards: cardsInfo });
    });
  } else {
    res.redirect("/login");
  }
});

// to display all cards info with employees for admin
myApp.get("/Emp", function (req, res) {
  if (req.session.loggedIn) {
    EmpCard.find({}).exec(function (err, empcards) {
      // console.log(empcards);
      res.render("EmpCardsAdmin", { cards: empcards });
    });
  } else {
    res.redirect("/login");
  }
});

// to search gift cards based on Employee for admin
myApp.post("/searchEmp", function (req, res) {
  if (req.session.loggedIn) {
    MongoClient.connect(url, function (err, db) {
      if (err) throw err;
      var dbo = db.db("giftcards");
      // regular expression for any number of digits
      var regexCode = new RegExp("[0-9]+");
      var query = { barcodeNumber: req.body.search.trim() };
      if (regexCode.test(query.barcodeNumber)) {
        dbo.collection("empcards").find(query).toArray(function (err, result) {
            if (err) throw err;
            else {
              if (result == false) {
                res.render("failCode");
              }else{
                EmpCard.findOne({ _id: result[0]._id }).exec(function (err,card) {
                  if (err) {
                    res.render("failCode");
                  }
                  res.render("searchEmp", card);
                });
              }
            }
          });
      } else {
        res.render("failCode");
      }
    });
  } else {
    res.redirect("/login");
  }
});

// to display all gift cards for Employee
myApp.get("/allCardsEmp", function (req, res) {
  if (req.session.loggedIn) {
    Cards.find({}).exec(function (err, cards) {
      res.render("allCardsEmp", { cards: cards });
    });
  } else {
    res.redirect("/login");
  }
});

// to search gift cards based on barcode for admin
myApp.post("/searchText", function (req, res) {
  if (req.session.loggedIn) {
    MongoClient.connect(url, function (err, db) {
      if (err) throw err;
      var dbo = db.db("giftcards");
      // regular expression for any number of digits
      var regexCode = new RegExp("[0-9]+");
      var query = { barcodeNumber: req.body.search.trim() };
      if (regexCode.test(query.barcodeNumber)) {
        dbo.collection("cards").find(query).toArray(function (err, result) {
            if (err) throw err;
            else {
              if (result == false) {
                res.render("failSearch");
              } else {
                Cards.findOne({ _id: result[0]._id }).exec(function (err,card) {
                  res.render("searchCode", card);
                });
              }
            }
          });
      } else {
        res.render("failSearch");
      }
    });
  } else {
    res.redirect("/login");
  }
});

// to search gift cards based on barcode for Employee
myApp.post("/searchTextEmp", function (req, res) {
  if (req.session.loggedIn) {
    MongoClient.connect(url, function (err, db) {
      if (err) throw err;
      var dbo = db.db("giftcards");
      // regular expression for any number of digits
      var regexCode = new RegExp("[0-9]+");
      var query = { barcodeNumber: req.body.search.trim() };

      if (regexCode.test(query.barcodeNumber)) {
        dbo.collection("cards").find(query).toArray(function (err, result) {
            if (err) throw err;
            else {
              if (result == false) {
                res.render("failSearchEmp");
              } else {
                Cards.findOne({ _id: result[0]._id }).exec(function (err,card) {
                  res.render("searchCodeEmp", card);
                });
              }
            }
          });
      } else {
        res.render("failSearchEmp");
      }
    });
  } else {
    res.redirect("/login");
  }
});

// for Admin : saving card after redemption
myApp.post("/RedeemCard/:cardid", function (req, res) {
  if (req.session.loggedIn) {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
      //fetch status field
      var status = req.body.status;
      var cardId = req.params.cardid;
      Cards.findOne({ _id: cardId }).exec(function (err, card) {
        // update the card and save
        card.status = status;
        card.save();
        res.render("redeemSuccess"); // render allcards.ejs
      });
    } else {
      console.log(errors.array());
    }
  } else {
    res.redirect("/login");
  }
});

// for Emp;loyee : saving card after redemption
myApp.post("/RedeemCardEmp/:cardid", function (req, res) {
  if (req.session.loggedIn) {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
      //fetch status field
      var status = req.body.status;
      var cardId = req.params.cardid;
      Cards.findOne({ _id: cardId }).exec(function (err, card) {
        // update the card and save
        card.status = status;
        card.save();
        res.render("redeemSuccessEmp"); // render allcards.ejs
      });
    } else {
      console.log(errors.array());
    }
  } else {
    res.redirect("/login");
  }
});

// to delete a card form the database
myApp.get("/delete/:cardid", function (req, res) {
  if (req.session.loggedIn) {
    var cardId = req.params.cardid;
    Cards.findByIdAndDelete({ _id: cardId }).exec(function (err, card) {
      res.render("delete");
    });
  } else {
    res.redirect("/login");
  }
});

// to delete a Employee card form Db for admin
myApp.get("/deleteEmpInfo/:cardid", function (req, res) {
  if (req.session.loggedIn) {
    var cardId = req.params.cardid;
    EmpCard.findByIdAndDelete({ _id: cardId }).exec(function (err, card) {
      res.render("deleteEmpInfo");
    });
  } else {
    res.redirect("/login");
  }
});

// to update any gift card information for admin
myApp.get("/update/:cardid", function (req, res) {
  if (req.session.loggedIn) {
    var cardId = req.params.cardid;
    Cards.findOne({ _id: cardId }).exec(function (err, card) {
      res.render("edit", card);
    });
  } else {
    res.redirect("/login");
  }
});

// to update any gift card information for employee
myApp.get("/updateEmp/:cardid", function (req, res) {
  if (req.session.loggedIn) {
    var cardId = req.params.cardid;
    Cards.findOne({ _id: cardId }).exec(function (err, card) {
      res.render("editEmp", card);
    });
  } else {
    res.redirect("/login");
  }
});

// for admin
myApp.post(
  "/updateCard/:cardid",
  [
    check("customerfor", "Name is mandatory").trim().notEmpty(),
    check("customerforemail", "Email is mandatory").trim().notEmpty().isEmail(),
    check("customerbuying", "Customer name is mandatory").trim().notEmpty(),
    check("customerbuyingemail", "Customer email is mandatory")
      .trim()
      .notEmpty()
      .isEmail(),
  ],
  function (req, res) {
    if (req.session.loggedIn) {
      const errors = validationResult(req);
      if (errors.isEmpty()) {
        //fetch all the form fields
        var customerName = req.body.customerfor;
        var customerEmail = req.body.customerforemail;
        var customerBuyName = req.body.customerbuying;
        var customerBuyEmail = req.body.customerbuyingemail;
        var dept = req.body.department;
        var status = req.body.status;
        // find the gift card in database and update it
        var cardId = req.params.cardid;
        Cards.findOne({ _id: cardId }).exec(function (err, card) {
          card.forCustomer = customerName;
          card.forCustomerEmail = customerEmail;
          card.buyCustomer = customerBuyName;
          card.buyCustomerEmail = customerBuyEmail;
          card.department = dept;
          card.status = status;
          card.save();
          res.render("editSuccess");
        });
      } else {
        res.render("edit", {
          errors: errors.array(),
          userData: req.body,
        });
      }
    } else {
      res.redirect("/login");
    }
  }
);

// for Employee
myApp.post(
  "/updateCardEmp/:cardid",
  [
    check("customerfor", "Name is mandatory").trim().notEmpty(),
    check("customerforemail", "Email is mandatory").trim().notEmpty().isEmail(),
    check("customerbuying", "Customer name is mandatory").trim().notEmpty(),
    check("customerbuyingemail", "Customer email is mandatory")
      .trim()
      .notEmpty()
      .isEmail(),
  ],
  function (req, res) {
    if (req.session.loggedIn) {
      const errors = validationResult(req);
      if (errors.isEmpty()) {
        //fetch all the form fields
        var customerName = req.body.customerfor;
        var customerEmail = req.body.customerforemail;
        var customerBuyName = req.body.customerbuying;
        var customerBuyEmail = req.body.customerbuyingemail;
        var dept = req.body.department;
        var status = req.body.status;
        // find the gift card in database and update it
        var cardId = req.params.cardid;
        Cards.findOne({ _id: cardId }).exec(function (err, card) {
          card.forCustomer = customerName;
          card.forCustomerEmail = customerEmail;
          card.buyCustomer = customerBuyName;
          card.buyCustomerEmail = customerBuyEmail;
          card.department = dept;
          card.status = status;
          card.save();
          res.render("editSuccessEmp");
        });
      } else {
        res.render("editEmp", {
          errors: errors.array(),
          userData: req.body,
        });
      }
    } else {
      res.redirect("/login");
    }
  }
);

// post home page information and generate gift card
myApp.post(
  "/process",
  [
    check("customerfor", "Name is mandatory").trim().notEmpty(),
    check("customerforemail", "Email is mandatory").trim().notEmpty().isEmail(),
    check("customerbuying", "Customer name is mandatory").trim().notEmpty(),
    check("customerbuyingemail", "Customer email is mandatory")
      .trim()
      .notEmpty()
      .isEmail(),
    check("peoplecount").custom(mealCheck),
    check("mealoption1").custom(mealCheck),
    check("mealoption2").custom(mealCheck),
  ],
  function (req, res) {
    if (req.session.loggedIn) {
      // console.log(req.session.empName);
      var empNameLogin = req.session.empName;
      const errors = validationResult(req);
      if (errors.isEmpty()) {
        var customer = req.body.customer;
        var forCustomer = req.body.customerfor;
        var forCustomerEmail = req.body.customerforemail;
        var buyCustomer = req.body.customerbuying;
        var buyCustomerEmail = req.body.customerbuyingemail;
        var department = req.body.department;
        var totalPeople = req.body.peoplecount;
        var mealoption1 = req.body.mealoption1;
        var mealoption2 = req.body.mealoption2;
        var uniqueNumber1 = Math.floor(100000 + Math.random() * 900000);
        var uniqueNumber2 = Math.floor(100000 + Math.random() * 900000);
        var barcodeNumber = uniqueNumber1 * uniqueNumber2;
        var today = new Date();
        var dd = String(today.getDate()).padStart(2, "0");
        var mm = String(today.getMonth() + 1).padStart(2, "0"); //January is 0!
        var yyyy = today.getFullYear();
        var status = "Active";
        today = mm + "/" + dd + "/" + yyyy;
        var data = {
          status: status,
          customer: customer,
          forCustomer: forCustomer,
          forCustomerEmail: forCustomerEmail,
          buyCustomer: buyCustomer,
          buyCustomerEmail: buyCustomerEmail,
          department: department,
          totalPeople: totalPeople,
          mealoption1: mealoption1,
          mealoption2: mealoption2,
          barcodeNumber: barcodeNumber,
          today: today,
          empNameLogin: empNameLogin,
        };

        var data2 = {
          customer: customer,
          forCustomer: forCustomer,
          forCustomerEmail: forCustomerEmail,
          buyCustomer: buyCustomer,
          buyCustomerEmail: buyCustomerEmail,
          barcodeNumber: barcodeNumber,
        };

        var data3 = {
          barcodeNumber: barcodeNumber,
          totalPeople: totalPeople,
          mealoption1: mealoption1,
          mealoption2: mealoption2,
          today: today,
        };

        var data4 = {
          empNameLogin: empNameLogin,
          barcodeNumber: barcodeNumber,
          today: today,
        };
        // console.log(data);
        var cardOrder = new Cards(data);
        cardOrder.save();

        // var customerdata = new CustomerInfo(data2);
        // customerdata.save();

        // var cardSave = new CardInfo(data3);
        // cardSave.save();

        var empData = new EmpCard(data4);
        empData.save();

        res.render("barcode", data);
      } else {
        res.render("home", {
          errors: errors.array(),
          userData: req.body,
        });
      }
    } else {
      res.redirect("/login");
    }
  }
);

myApp.post("/sendEmail", function (req, res) {
  //   console.log("hi hello");
  // console.log("req.body:", req.body);
  var forCustomer = req.body.forCustomer;
  var forCustomerEmail = req.body.forCustomerEmail;
  var buyCustomer = req.body.buyCustomer;
  var buyCustomerEmail = req.body.buyCustomerEmail;
  var department = req.body.department;
  var totalPeople = req.body.peoplecount;
  var mealoption1 = req.body.mealoption1;
  var mealoption2 = req.body.mealoption2;
  var barcodeNumber = req.body.barcodeNumber;
  // console.log("imageName: ", imageName);
  let transporter = nodemailer.createTransport({
    service: "gmail",
    port: 465,
    secureConnection: true,
    auth: {
      user: "lwchaca@gmail.com",
      pass: "xhgpskvtzplccoxj",
    },
  });

    var imgpath = `C:\\Users\\himan\\Downloads\\${barcodeNumber}.png`;
  // var imgpath = `C:\\Users\\wlhdh\\Downloads\\${barcodeNumber}.png`;
  if (forCustomerEmail == buyCustomerEmail) {
    let mailOptions = {
      from: "lwchaca@gmail.com",
      to: forCustomerEmail,
      subject: "Thank you for buying a Bloom Gift card",
      html:
        "Hi " +
        forCustomer +
        ", " +
        " this is your Bloom Gift Card(NO. " +
        barcodeNumber +
        ") worth for " +
        totalPeople +
        " people (2-Course meal for " +
        mealoption1 +
        " and 3-Course meal for " +
        mealoption2 +
        ")." +
        `<p>Click here for <a href="https://www.bloomatconestoga.ca/menus">Menu</a></p>` +
        `<p>Click here to visit our <a href="https://www.instagram.com/kwbloom/">Instagram</a></p>` +
        '<img src="cid:00001"/>' +
        `<br>` +
        "Regards," +
        `<br>` +
        "Bloom Management",

      attachments: [
        {
          filename: `Digit Gift Card of Bloom Restaurant.png`,
          path: imgpath,
          cid: "00001",
        },
      ],
    };

    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        return console.log(error);
      }
      // console.log("the email is sent to receiver successfully", info);
      // console.log('Server responded with "%s"', info.response);
      transporter.close();
    });
  } else {
    let mailOptions = {
      from: "lwchaca@gmail.com",
      to: forCustomerEmail,
      subject: buyCustomer + " sent you Bloom Gift card",
      html:
        "Hi " +
        forCustomer +
        ", " +
        buyCustomer +
        " sent you a Bloom Gift Card(NO. " +
        barcodeNumber +
        ") worth for " +
        totalPeople +
        " people (2-Course meal for " +
        mealoption1 +
        " and 3-Course meal for " +
        mealoption2 +
        ")." +
        `<p>Click here for <a href="https://www.bloomatconestoga.ca/menus">Menu</a></p>` +
        `<p>Click here to visit our <a href="https://www.instagram.com/kwbloom/">Instagram</a></p>` +
        '<img src="cid:00001"/>' +
        `<br>` +
        "Regards," +
        `<br>` +
        "Bloom Management",

      attachments: [
        {
          filename: `Digit Gift Card of Bloom Restaurant.png`,
          path: imgpath,
          cid: "00001",
        },
      ],
    };

    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        return console.log(error);
      }
      console.log("the email is sent to receiver successfully", info);
      console.log('Server responded with "%s"', info.response);
      transporter.close();
    });

    let mailFrom = {
      from: "lwchaca@gmail.com",
      to: buyCustomerEmail,
      subject:
        "The Bloom Gift card you bought has been sent to " +
        forCustomer +
        " successfully",
      text:
        "Hi " +
        buyCustomer +
        ", " +
        "Thank you for buying gift card from Bloom Restaurant. It has been successfully sent to:" +
        forCustomer +
        " at " +
        forCustomerEmail,
    };

    transporter.sendMail(mailFrom, (error, info) => {
      if (error) {
        return console.log(error);
      }
      console.log("the email is sent to buyer successfully", info);
      console.log('Server responded with "%s"', info.response);
      transporter.close();
    });
  }
  res.render("emailSuccess");
});

myApp.get("/setup", function (req, res) {
  let adminData = [
    {
      adminName: "darryl",
      adminPass: "darryl",
    },
    {
      adminName: "shannon",
      adminPass: "shannon",
    },
  ];
  let empData = [
    {
      empName: "sunny",
      empPass: "sunny",
    },
    {
      empName: "meet",
      empPass: "patel",
    },
    {
      empName: "himanshu",
      empPass: "himanshu",
    },
  ];
  Admin.collection.insertMany(adminData);
  Employee.collection.insertMany(empData);
  res.send("data added");
});

// start the server (listen at a port)
myApp.listen(8080);
console.log("Everything executed, Open http://localhost:8080/ in the browser");
